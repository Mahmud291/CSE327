<?php

namespace App\Http\Controllers;


use App\Models\ExamchoreUser;
use Illuminate\Http\Request;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Session;
use function PHPUnit\Framework\isEmpty;

class EnrolUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {

        $candidats = ExamchoreUser::where('examchore_id', $id)->get();
        return view('chore.addCandidate',compact('id','candidats'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
//        return $request->all();
        $user = Auth::user()->email;

        if($user == $request->email){
            Session::flash('warning', "Sorry, You can't add yourself!");
            return redirect()->back() ;
        }

        $candidate = User::where('email', $request->email)->get();


        $c_id = $request->examchore_id;

        if (sizeof($candidate) > 0){

            $user_id = $candidate[0]->id;
            $EnrolUserEmail = ExamchoreUser::where([
                ["examchore_id", "=", $c_id],
                ["user_id", "=", $user_id]
            ])->get();
            if( sizeof($EnrolUserEmail) == 0 ){
//                return $candidate;
                ExamchoreUser::create([
                    'user_id' => $candidate[0]->id,
                    'examchore_id' => $request->examchore_id,
                ]);
                Session::flash('success', "Candidate added successfully");
                return redirect()->back();

            }else{
                Session::flash('warning', "Candidate already exist");
                return redirect()->back();
            }

        }else{
            Session::flash('warning', "Email doesn't exist");
            return redirect()->back();
        }




    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\EnrolUser  $enrolUser
     * @return \Illuminate\Http\Response
     */
    public function show(EnrolUser $enrolUser)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\EnrolUser  $enrolUser
     * @return \Illuminate\Http\Response
     */
    public function edit(EnrolUser $enrolUser)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\EnrolUser  $enrolUser
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EnrolUser $enrolUser)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\EnrolUser  $enrolUser
     * @return \Illuminate\Http\Response
     */
    public function destroy(EnrolUser $enrolUser)
    {
        //
    }
}
