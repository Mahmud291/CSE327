<?php

namespace App\Http\Controllers;

use App\Models\Question;
use App\Models\Viva;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class VivaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
       return view('viva.create', compact('id'));
//        return view('viva.viva-test', compact('id'));
        // return view('viva.cr', compact('id'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:wav|max:2048',
            'ans' => 'required|mimes:wav|max:2048',
            'type' => 'required ',
            'time' => 'required |numeric|min:1|max:300',
            'point' => 'required |numeric|min:0|max:100',
        ]);
        $question_id = Question::create([
            'type' => $request->type,
            'assessment_id' => $request->assessment_id,
            'time' => $request->time,
            'point' => $request->point,
        ]);

        if($question_id->id ){
            $fileName = time().'-que.'.$request->file->extension();
            $request->file->move(public_path('file'), $fileName);

            $ansFileName = time().'-ans.'.$request->ans->extension();
            $request->ans->move(public_path('file'), $ansFileName);

            Viva::create([
                'file_name' => $fileName,
                'ans_file_name' => $ansFileName,
                'question_id' => $question_id->id,
            ]);
            return response()->json('File uploaded successfully');
        }else{
            Question::find($question_id->id)->delete();
            return response()->json('File upload failed');
        }


        // File::create(['name' => $fileName]);


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Viva  $viva
     * @return \Illuminate\Http\Response
     */
    public function show(Viva $viva)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Viva  $viva
     * @return \Illuminate\Http\Response
     */
    public function edit(Viva $viva)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Viva  $viva
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Viva $viva)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Viva  $viva
     * @return \Illuminate\Http\Response
     */
    public function destroy(Viva $viva)
    {
        //
    }
}
