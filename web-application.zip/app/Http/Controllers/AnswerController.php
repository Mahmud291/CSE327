<?php

namespace App\Http\Controllers;

use App\Models\Answer;
use App\Models\AnswerMcq;
use App\Models\answerViva;
use App\Models\Assessment;
use App\Models\Question;
use Illuminate\Http\Request;
use Session;
class AnswerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
//    function get
    public function create($user_id, $ass_id)
    {
//      dd( $user_id , $ass_id);
        $ger_question = Answer::where('assessment_id');
        $first_questions = Question::where('assessment_id',$ass_id)->inRandomOrder()->first();
        $questions = Question::where('assessment_id',$ass_id)->inRandomOrder()->get();

//        return $questions;
        $get_questions = Answer::where([
            'assessment_id' => $ass_id,
            'user_id' => $user_id,
        ])->get();

//        return $ger_questions;
        $question_lenhth = count($get_questions);
//        echo $question_lenhth;

        if ($question_lenhth > 0 ){

            for( $i = 0; $i< $question_lenhth; $i++){
                $answer_question[$i] =  $get_questions[$i]->question_id;
            }

            $return_question = Question::where('assessment_id',$ass_id)->whereNotIn('id',$answer_question)->inRandomOrder()->first();
            if ($return_question){
            return view('assessment.take-assessment', compact('return_question'));
            }else{
                $irl = '/candidate-assessment/'.$ass_id;
                return redirect($irl);
            }
        }else{
            $return_question = $first_questions;
//            return $return_question;

            return view('assessment.take-assessment', compact('return_question'));
        }


//        return $first_questions;

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $status = false;
        $mark = 0;
        if ( $request->type == 'mcq'){
            echo $request->question_id;
            $get_question = Question::find($request->question_id)->get_mcq;
            $answer = $get_question->mcq_answer;

            if ($request->answer == $answer){
                $status = true;
                $mark = $request->point;
            }

            $answers = Answer::create([
                'type' => $request->type,
                'assessment_id' => $request->assessment_id,
                'time' => $request->time,
                'point' => $request->point,
                'get_point'=> $mark,
                'status'=> $status,
                'question_id'=> $request->question_id,
                'user_id'=> $request->user_id,
            ]);

            if($answers->id ){
                AnswerMcq::create([

                    'mcq_answer' => $request->answer,
                    'answer_id' => $answers->id,
                ]);
                Session::flash('success', "MCQ created successfully");
                $irl = '/take-assessment/'.$request->user_id.'/'.$request->assessment_id;
                return redirect($irl);
            }else{
                Answer::find($answers->id)->delete();
                Session::flash('failed', "MCQ create failed");
                return redirect()->back() ;
            }
        }
        if ( $request->type == 'viva'){


//            return $request->all();
            echo $request->question_id;
            $get_question = Question::find($request->question_id)->get_viva;

            $answers = Answer::create([
                'type' => $request->type,
                'assessment_id' => $request->assessment_id,
                'time' => $request->time,
                'point' => $request->point,
                'get_point'=> $mark,
                'status'=> $status,
                'question_id'=> $request->question_id,
                'user_id'=> $request->user_id,
            ]);

            if($answers->id ){
                $ansFileName = time().'-ans1.'.$request->file->extension();
                $request->file->move(public_path('file'), $ansFileName);

                answerViva::create([
                    'ans_file_name' => $ansFileName,
                    'answer_id' => $answers->id,
                ]);

                return response()->json('File uploaded successfully');
            }
            else{
//                Answer::find($answers->id)->delete();
                return response()->json('File upload failed');
            }
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Answer  $answer
     * @return \Illuminate\Http\Response
     */
    public function show(Answer $answer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Answer  $answer
     * @return \Illuminate\Http\Response
     */
    public function edit(Answer $answer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Answer  $answer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Answer $answer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Answer  $answer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Answer $answer)
    {
        //
    }
}
