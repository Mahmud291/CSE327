<?php

namespace App\Http\Controllers;

use App\Models\Examchore;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Models\Assessment;


class ExamchoreController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $user = Auth::user()->id;
//        echo $user;
        $examChores = Examchore::where('user_id', $user)->get();
        $jouned = Examchore::where('user_id', $user)->with('joinedUsers')->get();
//        return $jouned;
        return view('chore.myExam',compact('examChores'));
    }
 /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function joined()
    {
        $user = Auth::user()->id;
        $examChores = User::find($user)->joinedChores;
//        return $examChores;
        return view('chore.joinedExam',compact('examChores'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('chore.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $request->validate([
            'name' => 'required | string | max:55 ',
        ]);
        $exam = Examchore::create([
            'name' => $request->name,
            'user_id' => $request->user_id,
        ]);

        Session::flash('success', "Exam-Chore created successfully");
        return redirect()->back() ;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Examchore  $examchore
     * @return \Illuminate\Http\Response
     */
    public function show(Examchore $examchore, $id)
    {
        $examChore = Examchore::find($id);
        $assessments = Assessment::where('examchore_id', $id)->get();
        $candidates = Examchore::find($id)->joinedUsers;
//         return $candidates;
        return view('chore.view',compact('examChore','assessments','candidates'));
    }


    public function showCandidate(Examchore $examchore, $id)
    {
        $examChore = Examchore::find($id);
        $assessments = Assessment::where('examchore_id', $id)->get();
        $candidates = Examchore::find($id)->joinedUsers;
//        return $candidates;
        return view('chore.candidate-view',compact('examChore','assessments',"candidates"));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Examchore  $examchore
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $examChore = Examchore::find($id);
        return view('chore.edit',compact('examChore'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Examchore  $examchore
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Examchore $examchore)
    {
        //
        $examChore = Examchore::where('id' , $request->id)->update([
            'name'=>$request->name
        ]);
        Session::flash('success', "Exam-Chore created successfully");
        return redirect()->back() ;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Examchore  $examchore
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        //
//        $examChore = Examchore::destroy($request->id);
        return redirect()->back();
    }
}
