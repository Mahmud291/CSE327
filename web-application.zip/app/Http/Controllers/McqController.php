<?php

namespace App\Http\Controllers;

use App\Models\Mcq;
use App\Models\Question;
use Illuminate\Http\Request;
use Session;
class McqController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        return view('mcq.create', compact('id'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)

    {
//        dd($request->assessment_id);
//        echo "safsdf f a";

        if ($request->mcq_answer == 1){
            $request->mcq_answer = $request->mcq_option1;
        }elseif ($request->mcq_answer == 2){
            $request->mcq_answer = $request->mcq_option2;
        }elseif ($request->mcq_answer == 3){
            $request->mcq_answer = $request->mcq_option3;
        }elseif ($request->mcq_answer == 4){
            $request->mcq_answer = $request->mcq_option4;
        }else{
            $request->mcq_answer = '';
        }
//         dd($request->mcq_answer);
        $request->validate([
            'mcq_title' => 'required | string | max:255 ',
            'mcq_option1' => 'required | string | max:55 ',
            'mcq_option2' => 'required | string | max:55 ',
            'mcq_option3' => 'required | string | max:55 ',
            'mcq_option4' => 'required | string | max:55 ',
            'mcq_answer' => 'required | in:1,2,3,4',
            'type' => 'required ',
            'time' => 'required |numeric|min:1|max:300',
            'point' => 'required |numeric|min:0|max:100',
        ]);
//        dd($request->all());
        if ($request->mcq_answer != ''){
            $question_id = Question::create([
                'type' => $request->type,
                'assessment_id' => $request->assessment_id,
                'time' => $request->time,
                'point' => $request->point,
            ]);
            if ($request->type == 'mcq'){
                if($question_id->id ){
                    Mcq::create([
                        'mcq_title' => $request->mcq_title,
                        'mcq_option1' => $request->mcq_option1,
                        'mcq_option2' => $request->mcq_option2,
                        'mcq_option3' => $request->mcq_option3,
                        'mcq_option4' => $request->mcq_option4,
                        'mcq_answer' => $request->mcq_answer,
                        'question_id' => $question_id->id,
                    ]);
                    Session::flash('success', "MCQ created successfully");
                    return redirect()->back() ;
                }else{
                    Question::find($question_id->id)->delete();
                    Session::flash('failed', "MCQ create failed");
                    return redirect()->back() ;
                }
            }

        }
        else{

            Session::flash('failed', "MCQ create failed");
            return redirect()->back() ;
        }




    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Mcq  $mcq
     * @return \Illuminate\Http\Response
     */
    public function show(Mcq $mcq)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Mcq  $mcq
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $mcq = Question::find($id);

        return view('mcq.edit', compact('mcq','id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Mcq  $mcq
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Mcq $mcq)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Mcq  $mcq
     * @return \Illuminate\Http\Response
     */
    public function destroy(Mcq $mcq)
    {
        //
    }
}
