<?php

namespace App\Http\Controllers;

use App\Models\Assessment;
use App\Models\Mcq;
use App\Models\Question;
use DateTime;
use Illuminate\Http\Request;
use Session;
use function MongoDB\BSON\toJSON;
Use \Carbon\Carbon;

class AssessmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        return view('assessment.create', compact('id'));
        // return view('assessment.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        // dd($request->all());
        $date = Carbon::now();
//        return  $date;
        if ($request->start_time <= $date){
            Session::flash('failed', "Start time must be getter then or equal to current time");
            return redirect()->back() ;
        }elseif ($request->due_time > $request->start_time){
            $request->validate([
                'name' => 'required | string  | max:55',
                'description' => 'required | string  | max: 255',
                'start_time' => 'required | date',
                'due_time' => 'required | date',
                'user_id' => 'required ',
                'examchore_id' => 'required ',
            ]);
//        return $request->all();

            Assessment::create([
                'name' => $request->name,
                'description' => $request->description,
                'start_time' => $request->start_time,
                'due_time' => $request->due_time,
                'user_id' => $request->user_id,
                'examchore_id' => $request->examchore_id,
            ]);
            Session::flash('success', "Exam-Chore created successfully");
            return redirect()->back() ;
        } else {
            Session::flash('failed', "Due time must be getter then Start time");
            return redirect()->back() ;
        }


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Assessment  $assessment
     * @return \Illuminate\Http\Response
     */
    public function show( $id)
    {
        $assessments = Assessment::find($id);

        $questions = Assessment::find($id)->get_question;
        $point = 0;
        $total_time = 0;

        foreach ($questions as  $item){
            $point += $item->point;
            $total_time += $item->time;
        }


        return view('assessment.view',
            compact(
                'assessments',
                'questions',
                'point',
                'total_time'
            ));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Assessment  $assessment
     * @return \Illuminate\Http\Response
     */
    public function joined( $id)
    {
        $assessments = Assessment::find($id);
//        $mcqs = Question::where('assessment_id', $id)->get();

        $questions = Assessment::find($id)->get_question;
//        $questions = Assessment::with('get_question')->get();

//        return $assessments;
        return view('assessment.candidate-view',compact('assessments','questions'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Assessment  $assessment
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $assessment = Assessment::find($id);
//        return $assessment;
        return view('assessment.edit',compact('assessment'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Assessment  $assessment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Assessment $assessment)
    {
        //
        $date = Carbon::now();
//        return  $date;
        if ($request->start_time <= $date){
            Session::flash('failed', "Start time must be getter then or equal to current time");
            return redirect()->back() ;
        }elseif ($request->due_time > $request->start_time){
            $request->validate([
                'name' => 'required | string  | max:55',
                'description' => 'required | string  | max: 255',
                'start_time' => 'required | date',
                'due_time' => 'required | date',
            ]);
//        return $request->all();

            Assessment::find($request->id)->update([
                "name"=> $request->name,
                "description"=> $request->description,
                "start_time"=> $request->start_time,
                "due_time"=> $request->due_time,
            ]);
            Session::flash('success', "Exam-Chore created successfully");
            return redirect()->back() ;
        } else {
            Session::flash('failed', "Due time must be getter then Start time");
            return redirect()->back() ;
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Assessment  $assessment
     * @return \Illuminate\Http\Response
     */
    public function destroy(Assessment $assessment)
    {
        //
    }
}
