<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mcq extends Model
{
    use HasFactory;
    protected $fillable = [

        'mcq_title' ,
        'mcq_option1',
        'mcq_option2',
        'mcq_option3',
        'mcq_option4',
        'mcq_answer',
        'question_id',
    ];

}
