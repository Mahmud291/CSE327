<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Examchore extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'name',
        'user_id',
    ];
    public function user(){
        return $this->belongsTo(User::class);
    }
    public function assessment(){
        return $this->hasMany(Assessment::class);
    }
    public function assessment_count(){
        return $this->hasMany(Assessment::class)->count();
    }
    public function joinedUsers(){
        return $this->belongsToMany(User::class);
    }
}
