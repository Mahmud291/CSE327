<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExamchoreUser extends Model
{
    use HasFactory;
    protected $fillable = [
        'examchore_id',
        'user_id',
    ];
    protected  $table='examchore_user';
}
