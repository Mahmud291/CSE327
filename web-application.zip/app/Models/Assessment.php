<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Assessment extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'user_id',
        'description',
        'start_time',
        'due_time',
        'examchore_id',
    ];

    public function examChore(){
        return $this->belongsTo(ExamchoreUser::class);
    }
    public function get_question(){
        return $this->hasMany(Question::class);
    }
    public function get_details(){
        return $this->hasMany(Question::class);
    }

}
