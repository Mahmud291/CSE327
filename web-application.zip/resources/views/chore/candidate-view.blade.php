<x-app-layout>
    <x-slot name="header" class="py-8">
        <div class="flex items-center justify-between p-1">
            <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                {{ $examChore->name }}
            </h2>
{{--            <div class="flex gap-5">--}}
{{--                <a href="{{route('add-candidate',$examChore->id)}}" class="text-gray-700 bg-blue-300 py-1.5 px-3 rounded-sm">Add Candidate</a>--}}
{{--                <a href="{{route('create-assesment',['id' => $examChore->id])}}" class="text-gray-700  bg-cyan-400 py-1.5 px-3 rounded-sm">Create Assessment</a>--}}
{{--            </div>--}}
        </div>
    </x-slot>
    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between p-3">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        {{ _("Assessments") }}
                    </h2>

                </div>
                <div class="m-4">
                <div class="flex flex-wrap m-4">
                    @if($assessments)
                    @foreach($assessments as $assessment)

                    <div class="xl:w-1/3 md:w-1/2 p-4">
                        <a href="{{route('candidate-assessment',['id' => $assessment->id])}}" class="border border-gray-200  rounded-lg shadow-xl block">
                            <div class=" items-center justify-center p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                <h2 class="text-xl text-gray-900 font-bold title-font ">{{$assessment->name}}</h2>

                            </div>
                            <div class="p-5">
                                <p class="leading-relaxed text-base">{{$assessment->description}}</p>

                            </div>
                        </a>
                    </div>
                        @endforeach
                    @else
                        <!-- <div class=" p-4 flex justify-center">
                            <a href="#" class="border border-gray-200  rounded-lg shadow-xl block">
                                <div class=" items-center justify-center p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                    <h2 class="text-xl text-gray-900 font-bold title-font ">No Exam-Chore Found</h2>

                                </div>
                                <div class="p-5">
                                    <p class="leading-relaxed text-base">Create your first Exam-Chore.<a href="{{route('create-exam-chore')}}" class="text-gray-700">Add Exam-Chore</a>
                                    </p>

                                </div>
                            </a>
                        </div> -->
                    @endif
                </div>
                </div>
            </div>
        </div>
    </div>
    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between p-3">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        {{ _("Other Candidates") }}
                    </h2>

                </div>
                <div class="m-4">
                    @foreach($candidates as $item)
                    <div class="p-4">
                        <div class="border border-gray-200  rounded-lg shadow-xl block">
                            <div class="flex items-center justify-between p-5 bg-indigo-100 text-indigo-500 ">
                                 <h3 class="text-xl text-gray-900 font-bold title-font ">{{$item->name}}</h3>
                                <p class="text-xl text-gray-900 font-bold title-font ">{{$item->email}}</p>
                            </div>

                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
