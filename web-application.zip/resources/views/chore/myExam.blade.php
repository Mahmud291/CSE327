<x-app-layout>
    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between p-3">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        {{ __('My Exam-Chore') }}
                    </h2>
                    <a href="{{route('create-exam-chore')}}" class="text-gray-700">Add Exam-Chore</a>
                </div>

                @if(sizeof($examChores) > 0)
                    <div class="flex flex-wrap m-4">
                        @foreach($examChores as $chore)

                            <div class="xl:w-1/3 md:w-1/2 p-4">
                                <div  class="border border-gray-200  rounded-lg shadow-xl ">
                                    <a href="{{route('show-exam-chore',['id' => $chore->id])}}" class="px-4 py-5 block bg-indigo-100 text-indigo-500 ">
                                        <h2 class="text-xl text-gray-900 font-bold title-font ">{{$chore->name}}</h2>
                                    </a>
                                    <div class="p-5">
                                        <?php $count = 0 ?>
                                        <p class="leading-relaxed text-base">
                                            Total Assessments:{{count($chore->assessment)}}

                                        </p>
                                            <p class="leading-relaxed text-base">
                                                Total Joined: {{count($chore->joinedUsers)}}

                                        </p>


                                    </div>
                                    <div class=" bg-indigo-400 flex rounded-l-2xl rounded-r-2xl">
                                        <a href="{{route('edit-exam-chore',['id' => $chore->id])}}" class="flex-1 rounded-bl-lg text-xl capitalize  py-3 text-center bg-green-800 text-white">edit</a>
                                        <form class="flex-1 flex" action="{{'delete-exam-chore'}}" method="post">
                                            @method('DELETE')
                                            @csrf
                                            <input type="hidden" name="id" value="{{$chore->id}}">
                                            <button type="submit"  class="flex-1  rounded-br-lg text-xl capitalize py-3 text-center bg-red-800 text-white">delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="">
                        <div class="m-8 border border-gray-200  rounded-lg shadow-xl flex flex-col">

                                <div class=" items-center justify-center p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                    <h2 class="text-xl text-gray-900 font-bold title-font ">No Exam-Chore Found</h2>

                                </div>
                                <div class="p-5">
                                    <p class="leading-relaxed text-base ">Create your first Exam-Chore.
                                        <a href="{{route('create-exam-chore')}}" class="text-blue-500">Add Exam-Chore</a>
                                    </p>
                                </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>


</x-app-layout>
