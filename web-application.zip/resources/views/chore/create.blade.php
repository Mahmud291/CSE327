<x-app-layout>
    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between p-3">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        {{ __('Add New Exam-Chore') }}
                    </h2>
                    <a href="{{route('my-exam-chore')}}" class="text-gray-700">Back</a>
                </div>
                <div class=" m-4">
                    @if(Session::has('success'))
                    <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg dark:bg-green-200 dark:text-green-800" role="alert">
                        <span class="font-medium">{{Session::get('success')}}</span>
                    </div>
                    @endif
                    <div class="">
                        <form action="store-exam-chore" method="POST">
                            @csrf

                            <div class="pb-6">

                                    <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Exam-Chore name</label>
                                <input type="text" name="name" placeholder="enter exam-chore name" id="name" class="bg-gray-50 border border-gray-300
                                 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                  dark:focus:border-blue-500"  required>


                                <p style="color:red">@error('name'){{$message}}@enderror</p>
                            </div>
                            <div class="pb-6">

                                <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
{{--                                {{ Auth::user()->name }}--}}

                            </div>

                            <br>
                            <div class="flex justify-center">
                                <button class="relative inline-flex items-center justify-center  p-0.5 mb-2 mr-2 overflow-hidden
                             text-sm font-medium text-gray-900 rounded-lg group bg-gradient-to-br from-purple-600
                             to-blue-500 group-hover:from-purple-600 group-hover:to-blue-500 hover:text-white
                             dark:text-white focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800" type="submit">
                                  <span class="relative w-96 px-5 py-2.5 transition-all ease-in duration-75 bg-white dark:bg-gray-900 rounded-md group-hover:bg-opacity-0">
                                      Save
                                  </span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
