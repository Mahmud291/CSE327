<x-app-layout>
    <x-slot name="header" class="py-8">
        <div class="flex items-center justify-between p-1">
            <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
{{--                {{ $assessments->name }}--}}
            </h2>
            <div class="flex gap-5">
                <a href="{{route('edit-assessment',['id' => $assessments->id])}}" class="text-gray-700 bg-blue-300 py-1.5 px-3 rounded-sm">Edit</a>
                <a href="{{route('delete-assessment',['id' => $assessments->id])}}" class="text-white bg-red-600 py-1.5 px-3 rounded-sm">Remove</a>

            </div>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="p-6 bg-white overflow-hidden shadow-xl sm:rounded-lg ">
                <div class="flex items-start justify-between">
                    <div class="">

                        <div class="flex items-center justify-start gap-5 mb-4">
                            <p class="font-semibold text-sm  leading-tight">
                                Start Time: <span class="text-blue-600">{{ $assessments->start_time }}</span>
                            </p>
                            <p class=" font-semibold text-sm  leading-tight">

                                End Time:    <span class="text-red-800">{{ $assessments->due_time }} </span>
                            </p>
                            <p class=" font-semibold text-sm  leading-tight">

                                Evolution Time:    <span class="text-green-500">
                                @if($total_time >=3600)
                                        {{gmdate("H:i:s", $total_time)}}
                                    @else
                                        {{gmdate("i:s", $total_time)}}
                                    @endif
                            </span>
                            </p>
                            <p class=" font-semibold text-sm  leading-tight">

                                Total Marks:    <span class="text-green-500">
                                {{$point }}
                            </span>
                            </p>

                        </div>

                    </div>
                    <div class="flex gap-5">
                        <a href="{{route('create-mcq',['id' => $assessments->id])}}" class="text-gray-700 bg-blue-300 py-1.5 px-3 rounded-sm">Add MCQ</a>
                        <a href="{{route('create-viva',['id' => $assessments->id])}}" class="text-gray-700 bg-blue-300 py-1.5 px-3 rounded-sm">Add Micro-Viva</a>

                    </div>
                </div>
                <div class="">
                    <h2 class="font-semibold text-md text-gray-800 leading-tight">
                        Description: {{ $assessments->description }}
                    </h2>
                </div>
            </div>

        </div>
    </div>



    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between px-6 py-4">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        {{ __('Assessment Question') }}

                    </h2>

                </div>
                <div class=" m-4">
                    @if($questions)
                    @foreach($questions as $mcq)

                    <div class=" p-4">
                        <div class="border border-gray-200  rounded-lg shadow-xl block">
                            <div class="flex items-center justify-between p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                @if($mcq->type == 'mcq')
                                <h2 class="text-xl text-gray-900 font-bold title-font ">{{$mcq->get_mcq->mcq_title}}</h2>
                                @endif

                                @if($mcq->type == 'viva')
                                <h2 class="text-xl text-gray-900 font-bold title-font ">Audio viva</h2>
                                @endif
                                <h2 class="text-xl text-gray-900 font-bold title-font ">Points: {{$mcq->point}}</h2>

                            </div>
                            @if($mcq->type == 'mcq')
                            <div class="p-4 flex flex-wrap ">

                                <div class=" md:w-1/2 p-2 flex items-center">
                                    <p class="leading-relaxed text-base w-60">Option 1</p>
                                    <p class="leading-relaxed text-base flex-1">{{$mcq->get_mcq->mcq_option1}}</p>
                                </div>
                                <div class=" md:w-1/2 p-2 flex items-center">

                                    <p class="leading-relaxed text-base w-60">Option 2</p>
                                    <p class="leading-relaxed text-base flex-1">{{$mcq->get_mcq->mcq_option2}}</p>
                                </div>
                                <div class=" md:w-1/2 p-2 flex items-center">

                                    <p class="leading-relaxed text-base w-60">Option 3</p>
                                    <p class="leading-relaxed text-base flex-1">{{$mcq->get_mcq->mcq_option3}}</p>
                                </div>
                                <div class=" md:w-1/2 p-2 flex items-center">

                                    <p class="leading-relaxed text-base w-60">Option 4</p>
                                    <p class="leading-relaxed text-base flex-1">{{$mcq->get_mcq->mcq_option4}}</p>
                                </div>
                                <div class=" md:w-1/2 p-2 flex items-center">

                                    <p class="leading-relaxed text-base w-60">Answer</p>
                                    <p class="leading-relaxed text-base flex-1">{{$mcq->get_mcq->mcq_answer}}</p>
                                </div>
                            </div>
                            @endif
                            @if($mcq->type == 'viva')
                                <div class="py-3">
                                    <div class="py-2 px-4 flex  items-center">
                                        <h3 style="width: 120px">Question:</h3>
                                        <audio controls >
                                            <source src="{{asset('file/'.$mcq->get_viva->file_name)}}" type="audio/wav">
                                        </audio>
                                    </div>

                                    <div class="  py-2 px-4  flex items-center">
                                        <h3 style="width: 120px">Answer:</h3>
                                        <audio controls >
                                            <source src="{{asset('file/'.$mcq->get_viva->ans_file_name)}}" type="audio/wav">
                                        </audio>
                                    </div>
                                </div>
                            @endif
                            <div class="flex items-center gap-5 px-4 py-2 justify-between bg-indigo-100 text-indigo-500">
                                <div class="flex items-center justify-start">

                                    <p class="leading-relaxed text-base text-black font-medium text-l ">Time: {{$mcq->time}} Second</p>

                                </div>
                                <div class=" gap-4 flex">
                                    @if($mcq->type == 'mcq')
                                        <a href="{{route('edit-mcq',['id' => $mcq->id])}}" class="text-xl text-white font-medium bg-green-800 title-font p-3 py-1 rounded-sm shadow-sm cursor-pointer">Edit</a>
                                    @endif

                                    @if($mcq->type == 'viva')
                                            <a href="{{route('edit-viva',['id' => $mcq->id])}}" class="text-xl text-white font-medium bg-green-800 title-font p-3 py-1 rounded-sm shadow-sm cursor-pointer">Edit</a>

                                        @endif
{{--                                    <a href="#" class="text-xl text-white font-medium title-font bg-red-500 px-3 py-1 rounded-sm shadow-sm cursor-pointer">Remove</a>--}}

                                </div>
                            </div>
                        </div>
                    </div>
                        @endforeach
                    @else
                         <div class=" p-4 flex justify-center">
                            <a href="#" class="border border-gray-200  rounded-lg shadow-xl block">
                                <div class=" items-center justify-center p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                    <h2 class="text-xl text-gray-900 font-bold title-font ">No Exam-Chore Found</h2>

                                </div>
                                <div class="p-5">
                                    <p class="leading-relaxed text-base">Create your first Exam-Chore.<a href="{{route('create-exam-chore')}}" class="text-gray-700">Add Exam-Chore</a>
                                    </p>

                                </div>
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

</x-app-layout>
