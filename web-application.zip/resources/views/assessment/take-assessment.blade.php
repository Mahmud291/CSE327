<x-app-layout>
    <x-slot name="header" class="py-8">

    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between px-6 py-4">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        {{ __('Assessment Question') }}

                    </h2>

                </div>
                <div class=" m-4">
                    <div class=" p-4">
                        @if($return_question->type == 'mcq')
                            <div class="border border-gray-200  rounded-lg shadow-xl block">
                                <form method="post" action="{{route('store-answer')}}" class="p-4">
                                    @csrf
                                    <div class="flex items-center justify-between p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                        <h2 class="text-xl text-gray-900 font-bold title-font ">{{$return_question->get_mcq->mcq_title}}</h2>
                                        <h2 class="text-xl text-gray-900 font-bold title-font ">Points: {{$return_question->point}}</h2>
                                    </div>
                                    <div class="">
                                        <div class="  p-2 flex items-center">
                                            <input type="radio" name="answer"
                                                   class="cursor-pointer"
                                                   value="{{$return_question->get_mcq->mcq_option1}}" id="{{$return_question->get_mcq->mcq_option1}}">
                                            <label class="text-base w-60 pl-2 cursor-pointer" for="{{$return_question->get_mcq->mcq_option1}}">{{$return_question->get_mcq->mcq_option1}}</label>
                                        </div>
                                        <div class="  p-2 flex items-center">
                                            <input type="radio" name="answer"
                                                   class="cursor-pointer"
                                                   value="{{$return_question->get_mcq->mcq_option2}}" id="{{$return_question->get_mcq->mcq_option2}}">
                                            <label class="text-base w-60 pl-2 cursor-pointer" for="{{$return_question->get_mcq->mcq_option2}}">{{$return_question->get_mcq->mcq_option2}}</label>
                                        </div>
                                        <div class="  p-2 flex items-center">
                                            <input type="radio" name="answer"
                                                   class="cursor-pointer"
                                                   value="{{$return_question->get_mcq->mcq_option3}}" id="{{$return_question->get_mcq->mcq_option3}}">
                                            <label class="text-base w-60 pl-2 cursor-pointer" for="{{$return_question->get_mcq->mcq_option3}}">{{$return_question->get_mcq->mcq_option3}}</label>
                                        </div>
                                        <div class="  p-2 flex items-center">
                                            <input type="radio" name="answer"
                                                   class="cursor-pointer"
                                                   value="{{$return_question->get_mcq->mcq_option4}}" id="{{$return_question->get_mcq->mcq_option4}}">
                                            <label class="text-base w-60 pl-2 cursor-pointer" for="{{$return_question->get_mcq->mcq_option4}}">{{$return_question->get_mcq->mcq_option4}}</label>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-5 px-4 py-2 justify-between bg-indigo-100 text-indigo-500">
                                        <div class="flex items-center justify-start">

                                            <p class="leading-relaxed text-base text-black font-medium text-l ">Time: {{$return_question->time}} Second</p>

                                        </div>
                                        <div class=" gap-4 flex">

                                            <input type="hidden" name="type" value="{{$return_question->type}}">
                                            <input type="hidden" name="point" value="{{$return_question->point}}">
                                            <input type="hidden" name="assessment_id" value="{{$return_question->assessment_id}}">
                                            <input type="hidden" name="question_id" value="{{$return_question->id}}">
                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                            <input type="submit" class="text-xl text-white font-medium bg-green-800 title-font p-3 py-1 rounded-sm shadow-sm cursor-pointer" value="Submit" />

                                        </div>
                                    </div>
                                </form>
                            </div>
                        @endif
                        @if($return_question->type == 'viva')
                                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

                                <form action="{{ route('store-answer') }}" method="POST" id="file-upload-ans" enctype="multipart/form-data">
                                @csrf
                                <div class="border border-gray-200  rounded-lg shadow-xl block">
                                    <div class="flex items-center justify-between p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                        <h2 class="text-xl text-gray-900 font-bold title-font ">Audio viva</h2>
                                        <h2 class="text-xl text-gray-900 font-bold title-font ">Points: {{$return_question->point}}</h2>
                                    </div>
                                    <div class="py-3">
                                        <div class="py-2 px-4 flex  items-center">
                                            <h3 style="width: 120px">Question:</h3>
                                            <audio controls >
                                                <source src="{{asset('file/'.$return_question->get_viva->file_name)}}" type="audio/wav">
                                            </audio>
                                        </div>

                                        <div class="p-2">
                                            <h2>Record Answer</h2>
                                            <div id="controls" class="controls gap-2 flex mb-2">
                                                <button id="recordButtona" class="py-1 px-4 cursor-pointer border bg-blue-300">Record</button>
                                                <button id="pauseButtona" class="py-1 px-4 cursor-pointer bg-cyan-300 border" disabled>Pause</button>
                                                <button id="stopButtona" class=" bg-red-600 text-white py-1 px-4 cursor-pointer border" disabled>Stop</button>
                                                <button id="clearButtona" type="button" class=" bg-indigo-500 text-white py-1 px-4 cursor-pointer border" disabled>Clear</button>
                                            </div>
                                            <div id="formats">Format: start recording to see sample rate</div>
                                            <p><strong>Recording:</strong></p>
                                            <div id="recordingsList"></div>
                                            <p class="audioa text-red-600"></p>
                                        </div>
                                        <div class=" gap-4 flex">

                                            <input type="hidden" name="type" value="{{$return_question->type}}">
                                            <input type="hidden" name="point" value="{{$return_question->point}}">
                                            <input type="hidden" name="assessment_id" value="{{$return_question->assessment_id}}">
                                            <input type="hidden" name="question_id" value="{{$return_question->id}}">
                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">


                                        </div>
                                    </div>
                                    <div class="flex items-center gap-5 px-4 py-2 justify-between bg-indigo-100 text-indigo-500">
                                        <div class="flex items-center justify-start">
                                            <p class="leading-relaxed text-base text-black font-medium text-l ">Time: {{$return_question->time}} Second</p>
                                        </div>
                                        <div class=" gap-4 flex">
                                            <input type="submit" class="text-xl text-white font-medium bg-green-800 title-font p-3 py-1 rounded-sm shadow-sm cursor-pointer" value="Submit" />

                                        </div>
                                    </div>
                                </div>
                            </form>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.rawgit.com/mattdiamond/Recorderjs/08e7abd9/dist/recorder.js"></script>
    <script type="text/javascript">

        //webkitURL is deprecated but nevertheless
        URL = window.URL || window.webkitURL;

        var gumStream;                      //stream from getUserMedia()
        var rec;                            //Recorder.js object
        var input;                          //MediaStreamAudioSourceNode we'll be recording

        // shim for AudioContext when it's not avb.
        var AudioContext = window.AudioContext || window.webkitAudioContext;
        var audioContext //audio context to help us record

        var recordButtona = document.getElementById("recordButtona");
        var stopButtona = document.getElementById("stopButtona");
        var pauseButtona = document.getElementById("pauseButtona");
        var clearButtona = document.getElementById("clearButtona");

        //add events to those 2 buttons
        recordButtona.addEventListener("click", startRecordinga);
        stopButtona.addEventListener("click", stopRecordinga);
        pauseButtona.addEventListener("click", pauseRecordinga);
        clearButtona.addEventListener("click", clearRecordinga);
        var blobData;
        var recordTime = 30000;

        function startRecordinga() {
            console.log("recordButton clicked");

            /*
                Simple constraints object, for more advanced audio features see
                https://addpipe.com/blog/audio-constraints-getusermedia/
            */

            var constraints = { audio: true, video:false }

            /*
                Disable the record button until we get a success or fail from getUserMedia()
            */

            recordButtona.disabled = true;
            stopButtona.disabled = false;
            pauseButtona.disabled = false;
            clearButtona.disabled = true;

            recordButtona.innerText = 'Recording';
            /*
                We're using the standard promise based getUserMedia()
                https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
            */

            navigator.mediaDevices.getUserMedia(constraints).then(function(stream) {
                console.log("getUserMedia() success, stream created, initializing Recorder.js ...");

                /*
                    create an audio context after getUserMedia is called
                    sampleRate might change after getUserMedia is called, like it does on macOS when recording through AirPods
                    the sampleRate defaults to the one set in your OS for your playback device

                */
                audioContext = new AudioContext();

                //update the format
                document.getElementById("formats").innerHTML="Format: 1 channel pcm @ "+audioContext.sampleRate/1000+"kHz"

                    /  assign to gumStream for later use  /
                gumStream = stream;

                / use the stream /
                input = audioContext.createMediaStreamSource(stream);

                /*
                    Create the Recorder object and configure to record mono sound (1 channel)
                    Recording 2 channels  will double the file size
                */
                rec = new Recorder(input,{numChannels:1})

                //start the recording process
                rec.record()

                console.log("Recording started");

            }).catch(function(err) {
                //enable the record button if getUserMedia() fails
                recordButtona.disabled = false;
                stopButtona.disabled = true;
                pauseButtona.disabled = true

            });
            setTimeout(function () {
                document.getElementById("stopButtona").click();
            }, recordTime);
        }

        function pauseRecordinga(){
            console.log("pauseButton clicked rec.recording=",rec.recording );
            if (rec.recording){
                //pause
                rec.stop();
                pauseButtona.innerHTML="Resume";
            }else{
                //resume
                rec.record()
                pauseButtona.innerHTML="Pause";
            }
        }

        function stopRecordinga() {
            console.log("stopButton clicked");

            //disable the stop button, enable the record too allow for new recordings
            stopButtona.disabled = true;
            recordButtona.disabled = true;
            pauseButtona.disabled = true;
            clearButtona.disabled = false;

            //reset button just in case the recording is stopped while paused
            pauseButtona.innerHTML="Pause";
            recordButtona.innerText = 'Record';
            //tell the recorder to stop the recording
            rec.stop();

            //stop microphone access
            gumStream.getAudioTracks()[0].stop();

            //create the wav blob and pass it on to createDownloadLink
            rec.exportWAV(createDownloadLinka);
        }

        function clearRecordinga(){
            console.log("clearRecording clicked rec.recording=",rec.recording );
            rec.clear();
            recordButtona.disabled = false;
            blobData = null;

            $('#recordingsList').empty();
            clearButtona.disabled = true;
        }
        function createDownloadLinka(blob) {

            var url = URL.createObjectURL(blob);
            blobData = blob;

            var au = document.createElement('audio');
            var li = document.createElement('div');
            var link = document.createElement('a');

            //name of .wav file to use during upload and download (without extendion)
            var filename = new Date().toISOString();

            //add controls to the <audio> element
            au.controls = true;
            au.src = url;

            //save to disk link
            link.href = url;
            link.download = filename+".wav"; //download forces the browser to donwload the file using the  filename
            link.innerHTML = "Save to disk";

            //add the new audio element to li
            li.appendChild(au);

            //add the filename to the li
            li.appendChild(document.createTextNode(filename+".wav "))

            //add the save to disk link to li
            // li.appendChild(link);

            //upload link
            // var upload = document.createElement('button');
            //
            // upload.innerHTML = "Upload";
            // upload.type = "button";
            // upload.addEventListener("click", function(event){
            // })
            li.appendChild(document.createTextNode (" "))//add a space in between
            // li.appendChild(upload)//add the upload link to li

            //add the li element to the ol
            recordingsList.append(li);
        }


        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#file-upload-ans').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            if(blobData == null ){
                $('.audioa').html('Please record Question.')
            }else {
                $('.audioa').html("")
                formData.append('file', blobData, 'blobData.wav');
            }
            //

            console.log(...formData);
            $('#file-input-errora').text('');


            // var  end_time = formData.get('time');
            // var  point = formData.get('point');
            //
            //
            //
            // if(end_time > 300 ){
            //     $('.time').html('End in must not be greater than 60s.')
            // }else {
            //     $('.time').html("")
            // }

            if( blobData != null){
                $.ajax({
                    type:'POST',
                    url: "{{ route('store-answer') }}",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: (response) => {
                        if (response) {
                            this.reset();
                            alert('File has been uploaded successfully');
                            // '/take-assessment/'
                            window.location.href = "{{url('take-assessment',[ 'user_id'=> Auth::user()->id , 'ass_id' => $return_question->assessment_id ])}}";
                        }
                    },
                    error: function(response){
                        window.location.href = "{{url('take-assessment',[ 'user_id'=> Auth::user()->id , 'ass_id' => $return_question->assessment_id ])}}";
                        //     $('#file-input-errora').text(response.responseJSON.message);
                    }
                });
            }


        });

    </script>
</x-app-layout>
