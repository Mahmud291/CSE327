<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, ['class' => 'py-8']); ?> 
        <div class="flex items-center justify-between p-1">
            <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                <?php echo e($examChore->name); ?>

            </h2>
            <div class="flex gap-5">
                <a href="<?php echo e(route('add-candidate',$examChore->id)); ?>" class="text-gray-700 bg-blue-300 py-1.5 px-3 rounded-sm">Add Candidate</a>
                <a href="<?php echo e(route('create-assessment',['id' => $examChore->id])); ?>" class="text-gray-700  bg-cyan-400 py-1.5 px-3 rounded-sm">Create Assessment</a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>
    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between p-3">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        <?php echo e(_("Assessments")); ?>

                    </h2>

                </div>
                <div class="m-4">
                <div class="flex flex-wrap m-4">
                    <?php if($assessments): ?>
                    <?php $__currentLoopData = $assessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="xl:w-1/3 md:w-1/2 p-4">
                        <a href="<?php echo e(route('view-assessment',['id' => $assessment->id])); ?>" class="border border-gray-200  rounded-lg shadow-xl block">
                            <div class=" items-center justify-center p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                <h2 class="text-xl text-gray-900 font-bold title-font "><?php echo e($assessment->name); ?></h2>

                            </div>
                            <div class="p-5">
                                <p class="leading-relaxed text-base"><?php echo e($assessment->description); ?></p>

                            </div>
                        </a>
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <!-- <div class=" p-4 flex justify-center">
                            <a href="#" class="border border-gray-200  rounded-lg shadow-xl block">
                                <div class=" items-center justify-center p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                    <h2 class="text-xl text-gray-900 font-bold title-font ">No Exam-Chore Found</h2>

                                </div>
                                <div class="p-5">
                                    <p class="leading-relaxed text-base">Create your first Exam-Chore.<a href="<?php echo e(route('create-exam-chore')); ?>" class="text-gray-700">Add Exam-Chore</a>
                                    </p>

                                </div>
                            </a>
                        </div> -->
                    <?php endif; ?>
                </div>
                </div>
            </div>
        </div>
    </div>
    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between p-3">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        <?php echo e(_("Candidates")); ?>

                    </h2>

                </div>
                <div class="m-4">
                    <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4">
                        <div class="border border-gray-200  rounded-lg shadow-xl block">
                            <div class="flex items-center justify-between p-5 bg-indigo-100 text-indigo-500 ">
                                 <h3 class="text-xl text-gray-900 font-bold title-font "><?php echo e($item->name); ?></h3>
                                <p class="text-xl text-gray-900 font-bold title-font "><?php echo e($item->email); ?></p>
                            </div>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH J:\XAMPP NEW\htdocs\Project-quiz-Master\web-application\resources\views/chore/view.blade.php ENDPATH**/ ?>