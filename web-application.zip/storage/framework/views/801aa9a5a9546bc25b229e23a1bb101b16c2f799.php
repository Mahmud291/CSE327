<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, ['class' => 'py-8']); ?> 

        <?php
        $date=date_create(now());
        date_add($date,date_interval_create_from_date_string("6 hours"));
        $nowDate = date_format($date,"Y-m-d H:i:s");
        ?>
        <div class="flex items-center justify-between p-1">
            <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                <?php echo e($assessments->name); ?>

            </h2>
            <div class="flex gap-5">

                <?php if($nowDate >= $assessments->start_time && $nowDate <= $assessments->due_time ): ?>
                <a href="<?php echo e(route('take-assessment',[ 'user_id'=> Auth::user()->id , 'ass_id' => $assessments->id ])); ?>" class="text-gray-700 bg-blue-300 py-1.5 px-3 rounded-sm">Start Now</a>
                <?php elseif($nowDate < $assessments->start_time): ?>
                <p  class="text-gray-700  py-1.5 px-3 rounded-sm">Start Soon</p>
                <?php elseif($nowDate > $assessments->end_time): ?>
                    <p  class="text-green-500 font-bold  py-1.5 px-3 rounded-sm">Finished</p>
                    <p  class="text-red-600 font-bold  py-1.5 px-3 rounded-sm">Missed</p>
                <?php endif; ?>
            </div>
        </div>


        <div class="flex items-center justify-start p-1 gap-5">
            <p class="font-semibold text-sm  leading-tight">
                Start Time: <span class="text-blue-600"><?php echo e($assessments->start_time); ?></span>
            </p>
            <p class=" font-semibold text-sm  leading-tight">

                End Time:    <span class="text-red-800"><?php echo e($assessments->due_time); ?> </span>
            </p>

        </div>
     <?php $__env->endSlot(); ?>


    <?php if($nowDate >= $assessments->start_time && $nowDate <= $assessments->due_time ): ?>
        <div class="py-8">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-4">
                    <div class="flex items-center justify-between p-3">
                        <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                            <?php echo e(__('Assessment Description')); ?>


                        </h2>

                    </div>
                    <div class=" m-4">
                        <h3 class="font-semibold text-xl text-gray-800 ">Description: <?php echo e($assessments->description); ?></h3>
                    </div>
                    <div class="flex justify-center">
                        <a href="<?php echo e(route('take-assessment',[ 'user_id'=> Auth::user()->id , 'ass_id' => $assessments->id ])); ?>" class="text-gray-700 bg-blue-300 py-1.5 px-3 rounded-sm">Start Now</a>

                    </div>
                </div>
            </div>
        </div>
    <?php elseif($nowDate < $assessments->start_time): ?>
        <div class="flex justify-center h-60 items-center">
            <p  class="text-gray-700 text-4xl py-1.5 px-3 font-bold rounded-sm">Start Soon...</p>
        </div>
    <?php elseif($nowDate > $assessments->end_time): ?>
        <p  class="text-green-500 font-bold  py-1.5 px-3 rounded-sm">Finished</p>
        <p  class="text-red-600 font-bold  py-1.5 px-3 rounded-sm">Missed</p>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH J:\XAMPP NEW\htdocs\Project-quiz-Master\web-application\resources\views/assessment/candidate-view.blade.php ENDPATH**/ ?>