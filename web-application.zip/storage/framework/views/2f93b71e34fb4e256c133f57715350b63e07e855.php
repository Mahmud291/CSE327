<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between p-3">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        <?php echo e(__('Add New MCQ')); ?>

                    </h2>
                    <a href="<?php echo e(url('view-assessment',$id)); ?>" class="text-gray-700">Back</a>
                </div>
                <div class=" m-4">
                    <?php if(Session::has('success')): ?>
                    <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg dark:bg-green-200 dark:text-green-800" role="alert">
                        <span class="font-medium"><?php echo e(Session::get('success')); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::has('failed')): ?>
                    <div class="p-4 mb-4 text-sm text-green-700 bg-red-100 rounded-lg dark:bg-green-200 dark:text-green-800" role="alert">
                        <span class="font-medium"><?php echo e(Session::get('failed')); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="">
                        <form action="<?php echo e(route('store-mcq')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="pb-6">

                                <label for="mcq_title" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">MCQ Title</label>
                                <input type="text" value="<?php echo e(old('mcq_title')); ?>" name="mcq_title" id="mcq_title" placeholder="enter assessment name" class="bg-gray-50 border border-gray-300
                                 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                  dark:focus:border-blue-500" required>


                                <p style="color:red"><?php $__errorArgs = ['mcq_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                            </div>


                            <div class="grid gap-6 mb-6 md:grid-cols-2">
                                <div>
                                    <label for="mcq_option1" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Option 1</label>
                                    <input type="text" value="<?php echo e(old('mcq_option1')); ?>" id="mcq_option1" name="mcq_option1" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required>
                                    <p style="color:red"><?php $__errorArgs = ['mcq_option1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                                <div>
                                    <label for="mcq_option2" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Option 2</label>
                                    <input type="text" value="<?php echo e(old('mcq_option2')); ?>"  id="mcq_option2" name="mcq_option2" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required>
                                    <p style="color:red"><?php $__errorArgs = ['mcq_option2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                                <div>
                                    <label for="mcq_option3" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Option 3</label>
                                    <input type="text" value="<?php echo e(old('mcq_option3')); ?>"  id="mcq_option3" name="mcq_option3" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required>
                                    <p style="color:red"><?php $__errorArgs = ['mcq_option3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                                <div>
                                    <label for="mcq_option4" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Option 4</label>
                                    <input type="text" value="<?php echo e(old('mcq_option4')); ?>"  id="mcq_option4" name="mcq_option4" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required>
                                    <p style="color:red"><?php $__errorArgs = ['mcq_option4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                            </div>
                            <div class="grid gap-6 mb-6 md:grid-cols-3">
                                <div>

                                    <label for="mcq_answer" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">MCQ Answer</label>

                                    <select name="mcq_answer" value="<?php echo e(old('mcq_answer')); ?>"  id="mcq_answer" class="bg-gray-50 border border-gray-300
                                 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                  dark:focus:border-blue-500" required>

                                        <option value="0">Select your answer</option>
                                        <option value="1">Option 1</option>
                                        <option value="2">Option 2</option>
                                        <option value="3">Option 3</option>
                                        <option value="4">Option 4</option>
                                    </select>


                                    <p style="color:red"><?php $__errorArgs = ['mcq_answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                                <div>

                                    <label for="time" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">End in ( second )</label>
                                    <input type="number" value="<?php echo e(old('time')); ?>"  name="time" id="tile" class="bg-gray-50 border border-gray-300
                                 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                  dark:focus:border-blue-500" required>


                                    <p style="color:red"><?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                                <div>

                                    <label for="point" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Marks</label>
                                    <input type="number" value="<?php echo e(old('point')); ?>"  name="point" id="point" class="bg-gray-50 border border-gray-300
                                 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                  dark:focus:border-blue-500" required>


                                    <p style="color:red"><?php $__errorArgs = ['point'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                            </div>



                            <div class="">

                                <!-- <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>"> -->
                                <input type="hidden" name="assessment_id" value="<?php echo e($id); ?>">
                                <input type="hidden" name="type" value="mcq">
                            </div>

                            <br>
                            <div class="flex justify-center">
                                <button class="relative inline-flex items-center justify-center  p-0.5 mb-2 mr-2 overflow-hidden
                                 text-sm font-medium text-gray-900 rounded-lg group bg-gradient-to-br from-purple-600
                                 to-blue-500 group-hover:from-purple-600 group-hover:to-blue-500 hover:text-white
                                 dark:text-white focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800" type="submit">
                                    <span class="relative w-96 px-5 py-2.5 transition-all ease-in duration-75 bg-white dark:bg-gray-900 rounded-md group-hover:bg-opacity-0">
                                        Save
                                    </span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH J:\XAMPP NEW\htdocs\Project-quiz-Master\web-application\resources\views/mcq/create.blade.php ENDPATH**/ ?>