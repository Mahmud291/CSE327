<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, ['class' => 'py-8']); ?> 
        <div class="flex items-center justify-between p-1">
            <h2 class="font-semibold text-2xl text-gray-800 leading-tight">

            </h2>
            <div class="flex gap-5">
                <a href="<?php echo e(route('edit-assessment',['id' => $assessments->id])); ?>" class="text-gray-700 bg-blue-300 py-1.5 px-3 rounded-sm">Edit</a>
                <a href="<?php echo e(route('delete-assessment',['id' => $assessments->id])); ?>" class="text-white bg-red-600 py-1.5 px-3 rounded-sm">Remove</a>

            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="p-6 bg-white overflow-hidden shadow-xl sm:rounded-lg ">
                <div class="flex items-start justify-between">
                    <div class="">

                        <div class="flex items-center justify-start gap-5 mb-4">
                            <p class="font-semibold text-sm  leading-tight">
                                Start Time: <span class="text-blue-600"><?php echo e($assessments->start_time); ?></span>
                            </p>
                            <p class=" font-semibold text-sm  leading-tight">

                                End Time:    <span class="text-red-800"><?php echo e($assessments->due_time); ?> </span>
                            </p>
                            <p class=" font-semibold text-sm  leading-tight">

                                Evolution Time:    <span class="text-green-500">
                                <?php if($total_time >=3600): ?>
                                        <?php echo e(gmdate("H:i:s", $total_time)); ?>

                                    <?php else: ?>
                                        <?php echo e(gmdate("i:s", $total_time)); ?>

                                    <?php endif; ?>
                            </span>
                            </p>
                            <p class=" font-semibold text-sm  leading-tight">

                                Total Marks:    <span class="text-green-500">
                                <?php echo e($point); ?>

                            </span>
                            </p>

                        </div>

                    </div>
                    <div class="flex gap-5">
                        <a href="<?php echo e(route('create-mcq',['id' => $assessments->id])); ?>" class="text-gray-700 bg-blue-300 py-1.5 px-3 rounded-sm">Add MCQ</a>
                        <a href="<?php echo e(route('create-viva',['id' => $assessments->id])); ?>" class="text-gray-700 bg-blue-300 py-1.5 px-3 rounded-sm">Add Micro-Viva</a>

                    </div>
                </div>
                <div class="">
                    <h2 class="font-semibold text-md text-gray-800 leading-tight">
                        Description: <?php echo e($assessments->description); ?>

                    </h2>
                </div>
            </div>

        </div>
    </div>



    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between px-6 py-4">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        <?php echo e(__('Assessment Question')); ?>


                    </h2>

                </div>
                <div class=" m-4">
                    <?php if($questions): ?>
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mcq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class=" p-4">
                        <div class="border border-gray-200  rounded-lg shadow-xl block">
                            <div class="flex items-center justify-between p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                <?php if($mcq->type == 'mcq'): ?>
                                <h2 class="text-xl text-gray-900 font-bold title-font "><?php echo e($mcq->get_mcq->mcq_title); ?></h2>
                                <?php endif; ?>

                                <?php if($mcq->type == 'viva'): ?>
                                <h2 class="text-xl text-gray-900 font-bold title-font ">Audio viva</h2>
                                <?php endif; ?>
                                <h2 class="text-xl text-gray-900 font-bold title-font ">Points: <?php echo e($mcq->point); ?></h2>

                            </div>
                            <?php if($mcq->type == 'mcq'): ?>
                            <div class="p-4 flex flex-wrap ">

                                <div class=" md:w-1/2 p-2 flex items-center">
                                    <p class="leading-relaxed text-base w-60">Option 1</p>
                                    <p class="leading-relaxed text-base flex-1"><?php echo e($mcq->get_mcq->mcq_option1); ?></p>
                                </div>
                                <div class=" md:w-1/2 p-2 flex items-center">

                                    <p class="leading-relaxed text-base w-60">Option 2</p>
                                    <p class="leading-relaxed text-base flex-1"><?php echo e($mcq->get_mcq->mcq_option2); ?></p>
                                </div>
                                <div class=" md:w-1/2 p-2 flex items-center">

                                    <p class="leading-relaxed text-base w-60">Option 3</p>
                                    <p class="leading-relaxed text-base flex-1"><?php echo e($mcq->get_mcq->mcq_option3); ?></p>
                                </div>
                                <div class=" md:w-1/2 p-2 flex items-center">

                                    <p class="leading-relaxed text-base w-60">Option 4</p>
                                    <p class="leading-relaxed text-base flex-1"><?php echo e($mcq->get_mcq->mcq_option4); ?></p>
                                </div>
                                <div class=" md:w-1/2 p-2 flex items-center">

                                    <p class="leading-relaxed text-base w-60">Answer</p>
                                    <p class="leading-relaxed text-base flex-1"><?php echo e($mcq->get_mcq->mcq_answer); ?></p>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if($mcq->type == 'viva'): ?>
                                <div class="py-3">
                                    <div class="py-2 px-4 flex  items-center">
                                        <h3 style="width: 120px">Question:</h3>
                                        <audio controls >
                                            <source src="<?php echo e(asset('file/'.$mcq->get_viva->file_name)); ?>" type="audio/wav">
                                        </audio>
                                    </div>

                                    <div class="  py-2 px-4  flex items-center">
                                        <h3 style="width: 120px">Answer:</h3>
                                        <audio controls >
                                            <source src="<?php echo e(asset('file/'.$mcq->get_viva->ans_file_name)); ?>" type="audio/wav">
                                        </audio>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="flex items-center gap-5 px-4 py-2 justify-between bg-indigo-100 text-indigo-500">
                                <div class="flex items-center justify-start">

                                    <p class="leading-relaxed text-base text-black font-medium text-l ">Time: <?php echo e($mcq->time); ?> Second</p>

                                </div>
                                <div class=" gap-4 flex">
                                    <?php if($mcq->type == 'mcq'): ?>
                                        <a href="<?php echo e(route('edit-mcq',['id' => $mcq->id])); ?>" class="text-xl text-white font-medium bg-green-800 title-font p-3 py-1 rounded-sm shadow-sm cursor-pointer">Edit</a>
                                    <?php endif; ?>

                                    <?php if($mcq->type == 'viva'): ?>
                                            <a href="<?php echo e(route('edit-viva',['id' => $mcq->id])); ?>" class="text-xl text-white font-medium bg-green-800 title-font p-3 py-1 rounded-sm shadow-sm cursor-pointer">Edit</a>

                                        <?php endif; ?>


                                </div>
                            </div>
                        </div>
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                         <div class=" p-4 flex justify-center">
                            <a href="#" class="border border-gray-200  rounded-lg shadow-xl block">
                                <div class=" items-center justify-center p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                    <h2 class="text-xl text-gray-900 font-bold title-font ">No Exam-Chore Found</h2>

                                </div>
                                <div class="p-5">
                                    <p class="leading-relaxed text-base">Create your first Exam-Chore.<a href="<?php echo e(route('create-exam-chore')); ?>" class="text-gray-700">Add Exam-Chore</a>
                                    </p>

                                </div>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH J:\XAMPP NEW\htdocs\Project-quiz-Master\web-application\resources\views/assessment/view.blade.php ENDPATH**/ ?>