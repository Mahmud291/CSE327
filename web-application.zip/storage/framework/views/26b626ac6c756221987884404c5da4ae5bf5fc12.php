


<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .controls button{
            font-weight: bold;
        }
        .controls button:disabled{
            opacity: .5;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between p-3">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        <?php echo e(__('Add New MCQ')); ?>

                    </h2>
                    <a href="<?php echo e(url('view-assessment',$id)); ?>" class="text-gray-700">Back</a>
                </div>
                <div class=" m-4">
                    <?php if(Session::has('success')): ?>
                        <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg dark:bg-green-200 dark:text-green-800" role="alert">
                            <span class="font-medium"><?php echo e(Session::get('success')); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('failed')): ?>
                        <div class="p-4 mb-4 text-sm text-green-700 bg-red-100 rounded-lg dark:bg-green-200 dark:text-green-800" role="alert">
                            <span class="font-medium"><?php echo e(Session::get('failed')); ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="">
                        <form action="<?php echo e(route('store-viva')); ?>" method="POST" id="file-upload" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="pb-6">
                                <h2>Record Question</h2>
                                <div id="controls" class="controls gap-2 flex mb-2">
                                    <button id="recordButton" class="py-1 px-4 cursor-pointer border bg-blue-300">Record</button>
                                    <button id="pauseButton" class="py-1 px-4 cursor-pointer bg-cyan-300 border" disabled>Pause</button>
                                    <button id="stopButton" class=" bg-red-600 text-white py-1 px-4 cursor-pointer border" disabled>Stop</button>
                                    <button id="clearButton" type="button" class=" bg-indigo-500 text-white py-1 px-4 cursor-pointer border" disabled>Clear</button>
                                </div>
                                <div id="formats">Format: start recording to see sample rate</div>
                                <p><strong>Recording:</strong></p>
                                <div id="recordingsList"></div>
                                <p class="audio1 text-red-600"></p>
                            </div>
                            <div class="pb-6">
                                <h2>Record Answer</h2>
                                <div id="controls2" class=" controls gap-2 flex mb-2">
                                    <button id="recordButton1" class="py-1 px-4 cursor-pointer border bg-blue-300">Record</button>
                                    <button id="pauseButton1" class="py-1 px-4 cursor-pointer border bg-cyan-300" disabled>Pause</button>
                                    <button id="stopButton1" class=" bg-red-600 text-white py-1 px-4 cursor-pointer border" disabled>Stop</button>
                                    <button id="clearButton1" type="button" class=" bg-indigo-500 text-white py-1 px-4 cursor-pointer border" disabled>Clear</button>
                                </div>
                                <div id="formats1">Format: start recording to see sample rate</div>
                                <p><strong>Recording:</strong></p>
                                <div id="recordingsList1"></div>
                                <p class="audio2 text-red-600"></p>
                            </div>



                            <div class="grid gap-6 mb-6 md:grid-cols-2">

                                <div>

                                    <label for="time" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">End in ( second )</label>
                                    <input type="number" value="<?php echo e(old('time')); ?>"  name="time" id="tile" class="bg-gray-50 border border-gray-300
                                 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                  dark:focus:border-blue-500" required>



                                    <p class="time text-red-600"></p>
                                </div>
                                <div>

                                    <label for="point" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Marks</label>
                                    <input type="number" value="<?php echo e(old('point')); ?>"  name="point" id="point" class="bg-gray-50 border border-gray-300
                                 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500
                                  dark:focus:border-blue-500" required>


                                    <p class="point text-red-600"></p>
                                </div>
                            </div>



                            <div class="">

                                <!-- <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>"> -->
                                <input type="hidden" name="assessment_id" value="<?php echo e($id); ?>">
                                <input type="hidden" name="type" value="viva">
                            </div>

                            <br>
                            <div class="flex justify-center">
                                <button type="submit" class=" relative inline-flex items-center justify-center  p-0.5 mb-2 mr-2 overflow-hidden
                                 text-sm font-medium text-gray-900 rounded-lg group bg-gradient-to-br from-purple-600
                                 to-blue-500 group-hover:from-purple-600 group-hover:to-blue-500
                                 dark:text-white focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800" type="submit">
                                    <span class="relative w-96 px-5 py-2.5 transition-all ease-in duration-75 bg-white dark:bg-gray-900 rounded-md group-hover:bg-opacity-0">
                                        Save
                                    </span>
                                </button>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.rawgit.com/mattdiamond/Recorderjs/08e7abd9/dist/recorder.js"></script>
    <script type="text/javascript">

        //webkitURL is deprecated but nevertheless
        URL = window.URL || window.webkitURL;

        var gumStream;                      //stream from getUserMedia()
        var rec;                            //Recorder.js object
        var input;                          //MediaStreamAudioSourceNode we'll be recording

        // shim for AudioContext when it's not avb.
        var AudioContext = window.AudioContext || window.webkitAudioContext;
        var audioContext //audio context to help us record

        var recordButton = document.getElementById("recordButton");
        var stopButton = document.getElementById("stopButton");
        var pauseButton = document.getElementById("pauseButton");
        var clearButton = document.getElementById("clearButton");

        //add events to those 2 buttons
        recordButton.addEventListener("click", startRecording);
        stopButton.addEventListener("click", stopRecording);
        pauseButton.addEventListener("click", pauseRecording);
        clearButton.addEventListener("click", clearRecording);
        var blobData;
        var ansBlobData;
        var recordTime = 30000;

        function startRecording() {
            console.log("recordButton clicked");

            /*
                Simple constraints object, for more advanced audio features see
                https://addpipe.com/blog/audio-constraints-getusermedia/
            */

            var constraints = { audio: true, video:false }

            /*
                Disable the record button until we get a success or fail from getUserMedia()
            */

            recordButton.disabled = true;
            stopButton.disabled = false;
            pauseButton.disabled = false;
            clearButton.disabled = true;

            recordButton.innerText = 'Recording';
            /*
                We're using the standard promise based getUserMedia()
                https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
            */

            navigator.mediaDevices.getUserMedia(constraints).then(function(stream) {
                console.log("getUserMedia() success, stream created, initializing Recorder.js ...");

                /*
                    create an audio context after getUserMedia is called
                    sampleRate might change after getUserMedia is called, like it does on macOS when recording through AirPods
                    the sampleRate defaults to the one set in your OS for your playback device

                */
                audioContext = new AudioContext();

                //update the format
                document.getElementById("formats").innerHTML="Format: 1 channel pcm @ "+audioContext.sampleRate/1000+"kHz"

                /*  assign to gumStream for later use  */
                gumStream = stream;

                /* use the stream */
                input = audioContext.createMediaStreamSource(stream);

                /*
                    Create the Recorder object and configure to record mono sound (1 channel)
                    Recording 2 channels  will double the file size
                */
                rec = new Recorder(input,{numChannels:1})

                //start the recording process
                rec.record()

                console.log("Recording started");

            }).catch(function(err) {
                //enable the record button if getUserMedia() fails
                recordButton.disabled = false;
                stopButton.disabled = true;
                pauseButton.disabled = true

            });
            setTimeout(function () {
                document.getElementById("stopButton").click();
            }, recordTime);
        }

        function pauseRecording(){
            console.log("pauseButton clicked rec.recording=",rec.recording );
            if (rec.recording){
                //pause
                rec.stop();
                pauseButton.innerHTML="Resume";
            }else{
                //resume
                rec.record()
                pauseButton.innerHTML="Pause";
            }
        }

        function stopRecording() {
            console.log("stopButton clicked");

            //disable the stop button, enable the record too allow for new recordings
            stopButton.disabled = true;
            recordButton.disabled = true;
            pauseButton.disabled = true;
            clearButton.disabled = false;

            //reset button just in case the recording is stopped while paused
            pauseButton.innerHTML="Pause";
            recordButton.innerText = 'Record';
            //tell the recorder to stop the recording
            rec.stop();

            //stop microphone access
            gumStream.getAudioTracks()[0].stop();

            //create the wav blob and pass it on to createDownloadLink
            rec.exportWAV(createDownloadLink);
        }

        function clearRecording(){
            console.log("clearRecording clicked rec.recording=",rec.recording );
            rec.clear();
            recordButton.disabled = false;
            blobData = null;

            $('#recordingsList').empty();
            clearButton.disabled = true;
        }
        function createDownloadLink(blob) {

            var url = URL.createObjectURL(blob);
            blobData = blob;

            var au = document.createElement('audio');
            var li = document.createElement('div');
            var link = document.createElement('a');

            //name of .wav file to use during upload and download (without extendion)
            var filename = new Date().toISOString();

            //add controls to the <audio> element
            au.controls = true;
            au.src = url;

            //save to disk link
            link.href = url;
            link.download = filename+".wav"; //download forces the browser to donwload the file using the  filename
            link.innerHTML = "Save to disk";

            //add the new audio element to li
            li.appendChild(au);

            //add the filename to the li
            li.appendChild(document.createTextNode(filename+".wav "))

            //add the save to disk link to li
            // li.appendChild(link);

            //upload link
            // var upload = document.createElement('button');
            //
            // upload.innerHTML = "Upload";
            // upload.type = "button";
            // upload.addEventListener("click", function(event){
            // })
            li.appendChild(document.createTextNode (" "))//add a space in between
            // li.appendChild(upload)//add the upload link to li

            //add the li element to the ol
            recordingsList.append(li);
        }

        var recordButton1 = document.getElementById("recordButton1");
        var stopButton1 = document.getElementById("stopButton1");
        var pauseButton1 = document.getElementById("pauseButton1");
        var clearButton1 = document.getElementById("clearButton1");

        //add events to those 2 buttons
        recordButton1.addEventListener("click", startRecording1);
        stopButton1.addEventListener("click", stopRecording1);
        pauseButton1.addEventListener("click", pauseRecording1);
        clearButton1.addEventListener("click", clearRecording1);

        function startRecording1() {
            console.log("recordButton clicked");

            /*
                Simple constraints object, for more advanced audio features see
                https://addpipe.com/blog/audio-constraints-getusermedia/
            */

            var constraints = { audio: true, video:false }

            /*
                Disable the record button until we get a success or fail from getUserMedia()
            */

            recordButton1.disabled = true;
            stopButton1.disabled = false;
            pauseButton1.disabled = false

            recordButton1.innerText = 'Recording';
            /*
                We're using the standard promise based getUserMedia()
                https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
            */

            navigator.mediaDevices.getUserMedia(constraints).then(function(stream) {
                console.log("getUserMedia() success, stream created, initializing Recorder.js ...");

                /*
                    create an audio context after getUserMedia is called
                    sampleRate might change after getUserMedia is called, like it does on macOS when recording through AirPods
                    the sampleRate defaults to the one set in your OS for your playback device

                */
                audioContext = new AudioContext();

                //update the format
                document.getElementById("formats1").innerHTML="Format: 1 channel pcm @ "+audioContext.sampleRate/1000+"kHz"

                /*  assign to gumStream for later use  */
                gumStream = stream;

                /* use the stream */
                input = audioContext.createMediaStreamSource(stream);

                /*
                    Create the Recorder object and configure to record mono sound (1 channel)
                    Recording 2 channels  will double the file size
                */
                rec = new Recorder(input,{numChannels:1})

                //start the recording process
                rec.record()

                console.log("Recording started");

            }).catch(function(err) {
                //enable the record button if getUserMedia() fails
                recordButton1.disabled = false;
                stopButton1.disabled = true;
                pauseButton1.disabled = true

            });
            setTimeout(function () {
                document.getElementById("stopButton1").click();
            }, recordTime);
        }

        function pauseRecording1(){
            console.log("pauseButton clicked rec.recording=",rec.recording );
            if (rec.recording){
                //pause
                rec.stop();
                pauseButton1.innerHTML="Resume";
            }else{
                //resume
                rec.record()
                pauseButton1.innerHTML="Pause";
            }
        }

        function stopRecording1() {
            console.log("stopButton clicked");

            //disable the stop button, enable the record too allow for new recordings
            stopButton1.disabled = true;
            recordButton1.disabled = true;
            pauseButton1.disabled = true;
            clearButton1.disabled = false;

            //reset button just in case the recording is stopped while paused
            pauseButton1.innerHTML="Pause";
            recordButton1.innerText = 'Record';
            //tell the recorder to stop the recording
            rec.stop();

            //stop microphone access
            gumStream.getAudioTracks()[0].stop();

            //create the wav blob and pass it on to createDownloadLink
            rec.exportWAV(createDownloadLink1);
        }

        function clearRecording1(){
            console.log("clearRecording clicked rec.recording=",rec.recording );
            rec.clear();
            recordButton1.disabled = false;
            ansBlobData = null;

            $('#recordingsList1').empty();
            clearButton1.disabled = true;
        }
        function createDownloadLink1(blob) {

            var url = URL.createObjectURL(blob);
            ansBlobData = blob;

            var au = document.createElement('audio');
            var li = document.createElement('div');
            var link = document.createElement('a');

            //name of .wav file to use during upload and download (without extendion)
            var filename = new Date().toISOString();

            //add controls to the <audio> element
            au.controls = true;
            au.src = url;

            //save to disk link
            link.href = url;
            link.download = filename+".wav"; //download forces the browser to donwload the file using the  filename
            link.innerHTML = "Save to disk";

            //add the new audio element to li
            li.appendChild(au);

            //add the filename to the li
            li.appendChild(document.createTextNode(filename+".wav "))

            //add the save to disk link to li
            // li.appendChild(link);

            //upload link
            // var upload = document.createElement('button');
            //
            // upload.innerHTML = "Upload";
            // upload.type = "button";
            // upload.addEventListener("click", function(event){
            // })
            li.appendChild(document.createTextNode (" "))//add a space in between
            // li.appendChild(upload)//add the upload link to li

            //add the li element to the ol
            recordingsList1.append(li);
        }


        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#file-upload').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            if(blobData == null ){
                $('.audio1').html('Please record Question.')
            }else {
                $('.audio1').html("")
                formData.append('file', blobData, 'blobData.wav');
            }
            if(ansBlobData == null ){
                $('.audio2').html('Please record answer.')
            }else {
                $('.audio2').html("")
                formData.append('ans', ansBlobData, 'ansBlobData.wav');
            }


            console.log(...formData);
            $('#file-input-error').text('');


            var  end_time = formData.get('time');
            var  point = formData.get('point');



            if(end_time > 300 ){
                $('.time').html('End in must not be greater than 60s.')
            }else {
                $('.time').html("")
            }
            if(point > 999 ){
                $('.point').html('Marks must not be greater than 3 characters.')
            }else {
                $('.point').html("")
            }
            if( (end_time <= 300 && end_time > 0 ) && (point <= 999 && point > 0) && blobData != null && ansBlobData != null){
                $.ajax({
                    type:'POST',
                    url: "<?php echo e(route('store-viva')); ?>",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: (response) => {
                        if (response) {
                            this.reset();
                            alert('File has been uploaded successfully');
                            window.location.href = "<?php echo e(url('view-assessment',$id)); ?>";
                        }
                    },
                    error: function(response){
                        $('#file-input-error').text(response.responseJSON.message);
                    }
                });
            }


        });

    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>






<?php /**PATH J:\XAMPP NEW\htdocs\Project-quiz-Master\web-application\resources\views/viva/create.blade.php ENDPATH**/ ?>