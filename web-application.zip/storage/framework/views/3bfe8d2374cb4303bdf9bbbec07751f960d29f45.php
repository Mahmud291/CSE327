<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="flex items-center justify-between p-3">
                    <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                        <?php echo e(__('Joined Exam-Chore')); ?>

                    </h2>
                </div>
                <?php if(sizeof($examChores) > 0): ?>
                    <div class="flex flex-wrap m-4">
                        <?php $__currentLoopData = $examChores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="xl:w-1/3 md:w-1/2 p-4">
                                <a href="<?php echo e(route('show-candidate-exam-chore',['id' => $chore->id])); ?>" class="border border-gray-200  rounded-lg shadow-xl block">
                                    <div class=" items-center justify-center p-5  bg-indigo-100 text-indigo-500 ">
                                        <h2 class="text-xl text-gray-900 font-bold title-font "><?php echo e($chore->name); ?></h2>
                                    </div>
                                    
                                    

                                    
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="">
                        <div class="m-8 border border-gray-200  rounded-lg shadow-xl flex flex-col">

                            <div class=" items-center justify-center p-5 mb-2 bg-indigo-100 text-indigo-500 ">
                                <h2 class="text-xl text-gray-900 font-bold title-font ">No Exam-Chore Found</h2>

                            </div>
                            <div class="p-5">
                                <p class="leading-relaxed text-base ">Create your first Exam-Chore.
                                    <a href="<?php echo e(route('create-exam-chore')); ?>" class="text-blue-500">Add Exam-Chore</a>
                                </p>
                            </div>
                        </div>
                    </div>
                        <?php endif; ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH J:\XAMPP NEW\htdocs\Project-quiz-Master\web-application\resources\views/chore/joinedExam.blade.php ENDPATH**/ ?>