<h1>all exam chore</h1>
<?php /**PATH K:\Laravel\q-quiz-auth\google-auth\resources\views/chore/myExam.blade.php ENDPATH**/ ?>
