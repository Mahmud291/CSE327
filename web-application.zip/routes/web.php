<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\GoogleController;
use App\Http\Controllers\ExamchoreController;
use App\Http\Controllers\AssessmentController;
use App\Http\Controllers\McqController;

use App\Http\Controllers\EnrolUserController;
use App\Http\Controllers\VivaController;
use App\Http\Controllers\AnswerController;

use App\Models\User;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::middleware(['auth:sanctum',config('jetstream.auth_session'),'verified'])->group(function () {
    Route::get('/dashboard', function () {
        $user = Auth::user()->id;

        $exam_chores = User::find($user)->examMyChores;
        $joined_chore = User::find($user)->joinedChores;

        return view('dashboard',compact('exam_chores','joined_chore'));
    })->name('dashboard');
    Route::get('/my-exam-chore', [ExamchoreController::class, 'index'])->name('my-exam-chore');
    Route::get('/joined-exam-chore', [ExamchoreController::class, 'joined'])->name('joined-exam-chore');
    Route::get('/create-exam-chore', [ExamchoreController::class, 'create'])->name('create-exam-chore');
    Route::post('/store-exam-chore', [ExamchoreController::class, 'store'])->name('store-exam-chore');
    Route::get('/edit-exam-chore/{id}', [ExamchoreController::class, 'edit'])->name('edit-exam-chore');
    Route::post('/update-exam-chore', [ExamchoreController::class, 'update'])->name('update-exam-chore');
    Route::delete('/delete-exam-chore', [ExamchoreController::class, 'destroy'])->name('delete-exam-chore');


    Route::get('/exam-chore/{id}', [ExamchoreController::class, 'show'])->name('show-exam-chore');
    Route::get('/exam-chore-candidate/{id}', [ExamchoreController::class, 'showCandidate'])->name('show-candidate-exam-chore');
    Route::get('/create-assessment/{id}', [AssessmentController::class, 'create'])->name('create-assessment');
    Route::get('/edit-assessment/{id}', [AssessmentController::class, 'edit'])->name('edit-assessment');
    Route::post('/update-assessment', [AssessmentController::class, 'update'])->name('update-assessment');
    Route::get('/delete-assessment/{id}', [AssessmentController::class, 'destroy'])->name('delete-assessment');
    Route::get('/view-assessment/{id}', [AssessmentController::class, 'show'])->name('view-assessment');
    Route::get('/candidate-assessment/{id}', [AssessmentController::class, 'joined'])->name('candidate-assessment');
    Route::post('/store-assessment', [AssessmentController::class, 'store'])->name('store-assessment');


    Route::get('/create-mcq/{id}', [McqController::class, 'create'])->name('create-mcq');
    Route::post('/store-mcq', [McqController::class, 'store'])->name('store-mcq');
    Route::get('/edit-mcq/{id}', [McqController::class, 'edit'])->name('edit-mcq');
    Route::post('/update-mcq', [McqController::class, 'update'])->name('update-mcq');


    Route::get('/create-viva/{id}', [VivaController::class, 'create'])->name('create-viva');
    Route::post('/store-viva', [VivaController::class,'store'])->name('store-viva');
    Route::get('/edit-viva/{id}', [VivaController::class, 'edit'])->name('edit-viva');

    Route::get('/add-candidate/{id}', [EnrolUserController::class, 'index'])->name('add-candidate');
    Route::post('/store-candidate', [EnrolUserController::class, 'store'])->name('store-candidate');


    Route::get('/take-assessment/{user_id}/{ass_id}', [AnswerController::class, 'create'])->name('take-assessment');
    Route::post('/store-answer', [AnswerController::class, 'store'])->name('store-answer');


});



Route::get('auth/google', [GoogleController::class, 'redirectToGoogle'])->name('auth.google');
Route::get('callback', [GoogleController::class,'handleGoogleCallback']);
